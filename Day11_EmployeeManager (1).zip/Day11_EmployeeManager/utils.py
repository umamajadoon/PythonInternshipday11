def calculate_average_salary(employee_list):
    if not employee_list:
        return 0
    return sum(e.salary for e in employee_list) / len(employee_list)
