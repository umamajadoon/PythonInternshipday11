class Employee:
    def __init__(self, name, department, salary, joining_year):
        self.name = name
        self.department = department
        self.salary = float(salary)
        self.joining_year = int(joining_year)

    def display(self):
        return f"{self.name} | {self.department} | ${self.salary:.2f} | Joined: {self.joining_year}"
