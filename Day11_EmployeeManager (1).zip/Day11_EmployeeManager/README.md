# Day11_EmployeeManager

## Task Overview
A file-based employee record system that uses:
- OOP (classes, inheritance)
- File handling (read/write from file)
- Search (lambda), sorting, and exception handling
- Modular design and reusable utility module

## Features
- Add, list, search, and sort employee records
- Automatically loads from and saves to file
- Generates a report with summary

## How to Run
```bash
python main.py
```

## File Structure
- `employee.py` - Employee class
- `manager.py` - EmployeeManager logic
- `utils.py` - Utility functions
- `main.py` - CLI menu driver
- `employee_data.txt` - Persistent employee data
- `employee_report.txt` - Summary report output
