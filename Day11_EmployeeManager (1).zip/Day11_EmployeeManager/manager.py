from employee import Employee
import utils

class EmployeeManager:
    def __init__(self, data_file):
        self.data_file = data_file
        self.employees = []
        self.load_data()

    def load_data(self):
        try:
            with open(self.data_file, "r") as file:
                for line in file:
                    parts = line.strip().split(",")
                    if len(parts) == 4:
                        emp = Employee(*parts)
                        self.employees.append(emp)
        except FileNotFoundError:
            pass

    def save_data(self):
        with open(self.data_file, "w") as file:
            for emp in self.employees:
                file.write(f"{emp.name},{emp.department},{emp.salary},{emp.joining_year}\n")

    def add_employee(self):
        try:
            name = input("Enter Name: ")
            department = input("Enter Department: ")
            salary = float(input("Enter Salary: "))
            year = int(input("Enter Joining Year: "))
            emp = Employee(name, department, salary, year)
            self.employees.append(emp)
            print("Employee added successfully.")
        except ValueError:
            print("Invalid input. Please try again.")

    def list_employees(self):
        for emp in self.employees:
            print(emp.display())

    def search_employee(self, term):
        result = list(filter(lambda e: term.lower() in e.name.lower() or term.lower() in e.department.lower(), self.employees))
        for emp in result:
            print(emp.display())

    def sort_by_salary(self, desc=False):
        self.employees.sort(key=lambda e: e.salary, reverse=desc)
        print("Sorted by salary.")
        self.list_employees()

    def generate_report(self, report_file):
        with open(report_file, "w") as f:
            f.write("Employee Report\n\n")
            for emp in self.employees:
                f.write(emp.display() + "\n")
            avg_salary = utils.calculate_average_salary(self.employees)
            f.write(f"\nAverage Salary: ${avg_salary:.2f}\n")
